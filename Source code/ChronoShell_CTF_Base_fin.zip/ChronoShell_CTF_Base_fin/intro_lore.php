<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>The Chronicles of Eldoria</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="terminal">
    <div class="header">📜 The Chronicles of Eldoria</div>
    <pre>
Long ago, before time itself was tamed, the realm of Eldoria flourished under the harmony of magic and steel.
But darkness has begun to seep through forgotten cracks...

The ChronoShell – a terminal relic lost to time – has reawakened.

Its powers allow brave souls to traverse the layers of reality and uncover the ancient vulnerabilities buried deep within Eldoria’s arcane web.

You are the chosen one.

Your destiny? To unveil the forbidden, decode the cursed, and test your might against twisted logic and traps left by the Ancients.

Use the terminal.
Invoke the relics.
Break the cycle.
    </pre>
    <a href="index.php" style="color: #00ff88;">← Return to the Terminal</a>
  </div>
</body>
</html>
